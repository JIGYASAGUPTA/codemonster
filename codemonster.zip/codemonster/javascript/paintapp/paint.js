var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");
context.linewidth =5;//default size of brush



var down = false;//mouse postion

canvas.addEventListener('mousemove',draw);
canvas.addEventListener('mousedown',function()
{
	down = true;
	context.beginPath();
	context.moveTo(xpos,ypos);
	canvas.addEventListener("mousemove",draw);

	
});

canvas.addEventListener('mouseup', function(){down = false});






function draw(e){
	
	xpos = e.clientX - canvas.offsetLeft;
	ypos = e.clientY - canvas.offsetTop;

	//alert(canvas.offsetLeft);
	//alert(canvas.offsetTop);

	//alert(xpos);
	//alert(ypos);

	if (down == true)
	{
		context.lineTo(xpos, ypos);
		context.stroke();
		

	}
}


function newcolor(color)
{
	

context.strokeStyle = color;
context.fillStyle = color;

}


function clear()
{
	
	
context.clearRect( 0 ,0 ,canvas.width , canvas.height);


}

function BrushSize(size){ context.lineWidth  = size   ;         }

function BrushStyle(style){ context.lineCap = style;  }


/* Touch event*/


canvas.addEventListener("touchmove", TouchMove , true);

function drawSquare( x ,y)
{
	context.fillRect(x, y, 10, 10);

}


function TouchMove(event)
{
	event.preventDefault();
	for( var n=0 ; n< event.touches.length ; n++)
	{
		
		drawSquare(event.touches[n].pageX, event.touches[n].pageY);
	}


}