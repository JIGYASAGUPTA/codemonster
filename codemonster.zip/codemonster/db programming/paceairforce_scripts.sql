
USE paceairforce;

select AID,model from aircraft where model IN(select model from aircraftperformance where climbrate > 1000);
select afid,name from airfield where afid in(select airfield from squadron where airfield="AF-001");
select concat(fname," ",lname) as name, rank from pilot where pid in(select pid from missionsflown where missioncount > 10);
select model, fuelrequirement from aircraftfuel where model in (select model from aircraftspecs where crew > 1);
select concat(fname," ",lname), pid as name from pilot where pid in(select PID from pilotassignment where AID in (select aid from aircraft where model = "P-51D"));
select fname,lname, length(Lname) from pilot where pid in (select pid from pilotassignment where aid in (select aid from aircraft where model="P-47D"));
select model,type,crew,weight from aircraftspecs where model in(select model from aircraftfuel where fuelrequirement > 1000) and model in (select model from aircraftperformance where stallspeed > 100) and model in(select model from aircraftarmament where Guncount > 2);
select * from aircraft where model in (select model from aircraftspecs where A_ceiling < 40000) and model in (select model from aircraftfuel where fuelrequirement > 1000) and model in (select model from aircraftperformance where stallspeed > 100) and model in (select model from aircraftarmament where Guncount > 8);