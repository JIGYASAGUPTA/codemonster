#question1

DELIMITER //
DROP PROCEDURE IF EXISTS droidView;
CREATE PROCEDURE droidView()
BEGIN
create or replace view droid_c_view as select idnumber, status, department, deactivateon, location from droids inner join department on droids.department=department.name where droids.department='c' and droids.status='Active' and droids.deactivateon not between 2016-03-01 and 2016-07-23 and year(droids.deactivateon)=2016;
SELECT COUNT(*) as Droidcount FROM droid_c_view as message;
Select location,count(*) as DroidCountS3 from droid_c_view as message;
END //
DELIMITER ;
CALL droidView();



#question2

DELIMITER //
DROP PROCEDURE IF EXISTS restore_droids;
CREATE PROCEDURE restore_droids() 
BEGIN
DROP TABLE IF EXISTS new_droids;
CREATE TABLE new_droids AS (SELECT IDNumber, Department, Status FROM droids); 
ALTER TABLE new_droids ADD COLUMN repair varchar(50);

UPDATE new_droids SET repair='Urgent Repair' WHERE Department='C';
UPDATE new_droids SET repair='Immediate Repair' WHERE Department='D';
UPDATE new_droids SET repair='Priority Repair' WHERE Department='E';
UPDATE new_droids SET repair='Routine Repair' WHERE Department='A' or Department = 'B'; 
select *from new_droids;
END //
DELIMITER ;
CALL restore_droids();                        




#question3
DELIMITER //
DROP PROCEDURE IF EXISTS droidDeactMonthCount ;
CREATE PROCEDURE droidDeactMonthCount ( range1 date , range2 date)
BEGIN

CREATE TABLE dead_droid
select idnumber , deactivateon from droids where  deactivateon >=range1 and deactivateon <= range2;
 select * from dead_droid;
select count(*)as early from droids where deactivateon >= DATE_ADD(range1,INTERVAL 30 DAY) ;
END //
DELIMITER ;
call droidDeactMonthCount('2017-03-01', '2017-07-23');





#question4


DELIMITER //
DROP PROCEDURE IF EXISTS droidCost   ;
CREATE PROCEDURE droidCost ( depname varchar(30))
BEGIN

declare totalcost DOUBLE PRECISION(10,2);
declare statuscheck int ;
declare percost double(10,2);

select sum(cost) into percost from droid_specs s inner join droids d on s.Typeid = d.TypeID where department = depname ;
select count(status) into statuscheck from droids where department = depname;

set totalcost =  percost * statuscheck ;

select totalcost as msg;

select concat_ws("",depname,'department has an inactive droidcount of ',statuscheck ,'droids for a total cost of ',totalcost , 'US dollars' );



END //
DELIMITER ;
call droidCost ('A');



